#Socola World
Nơi Socola biến những ý tưởng của mình thành hiện thực

Các chức năng chính:
- Ranking memmber
