<?php
	require_once __DIR__ . '/Controller.php';
	/**
	* 
	*/
	class Controller_BotRemindHashTag extends Controller
	{
		function __construct()
		{
			parent::__construct();
		}
		public function getBots($userID)
		{
			# code...
		}
	}
?>