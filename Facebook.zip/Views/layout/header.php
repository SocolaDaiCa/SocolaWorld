<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- meta -->
<meta property="fb:app_id" content="425249171186475">
<meta property="og:site_name" content="www.socola.tentstudy.xyz">
<meta property="og:type" content="website">
<meta property="og:title" content="Socola World" />
<meta property="og:description" content="Nơi Socola biến những ý tưởng của mình thành hiện thực" />
<meta property="og:url" content="https://socola.tentstudy.xyz/">
<meta property="og:image" content="https://tentstudy.xyz/images/banner_share_fb.png" />
<meta property="og:image:type" content="image/jpeg">
<meta property="og:locale" content="vi_VN">
<!-- /meta -->
<meta name="description" content="">
<meta name="author" content="">