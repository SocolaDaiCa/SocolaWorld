<!-- local -->
<!-- jQuery -->
<script src="/vendor/jquery/jquery.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="/vendor/jquery.cookie/jquery.cookie.js"></script>
<script src="/vendor/vue/vue.min.js"></script>
<script src="/vendor/socola.dai.ca/js/fb.js"></script>
<!-- <script src="/vendor/socola.dai.ca/js/socola.js"></script> -->
<!-- cdn -->

<!-- Bootstrap Core JavaScript -->
<script src="/vendor/bootstrap/js/bootstrap.min.js"></script>
<!-- Plugin JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script src="/vendor/scrollreveal/scrollreveal.min.js"></script>
<script src="/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
<!-- Theme JavaScript -->
<script src="/public/theme/js/creative.min.js"></script>