<?php
	/**
	* 
	*/
	require_once __DIR__ . '/../Controller/Controller_User.php';
	class View_Layout
	{
		
		function __construct()
		{
			
		}
		
	}
?>