<?php
	define('CLIENT_ID','425249171186475');
	define('REDIRECT_URI', $serverPath = $_SERVER["REQUEST_SCHEME"] . "://". $_SERVER["HTTP_HOST"] . "/return.php");
	define('CLIENT_SECRET','1723fe0ec79cd0cf142c93b9010ff5d8');
?>