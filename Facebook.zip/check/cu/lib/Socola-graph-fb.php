<?php
	/**
	* 
	*/
	require_once __DIR__ . '/Socola-php-function.php';
	class SocolaGraphFacebook
	{
		private $json;
		public $graph = 'https://graph.facebook.com/';
		function __construct()
		{
			
		}
		
		
		
		
	}
?>