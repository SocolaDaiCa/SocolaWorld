<div class="post">
	<div class="header_post">
		<div class="avatar">
			<div class="box-thumbnail"></div>
			<div class="box-thumbnail"></div>
			<div class="box-thumbnail"></div>
		</div>
		<div class="story">
			<div class="box-thumbnail"></div>
			<div class="box-thumbnail"></div>
			<div class="box-thumbnail"></div>
			<p class="small text-muted">
				
			</p>
		</div>
	</div>
	<div class="body_post">
		<div class="box-thumbnail"></div>
		<div class="box-thumbnail"></div>
		<div class="box-thumbnail"></div>
		<div class="box-thumbnail"></div>
		<div class="box-thumbnail"></div>
		<div class="box-thumbnail"></div>
		<div class="box-thumbnail"></div>
		<div class="box-thumbnail"></div>
		<div class="box-thumbnail"></div>
	</div>
	<div class="footer_post">
		<div class="action">
			<a href="#/" style="color: black;">
				<span>
					<span class="glyphicon glyphicon-thumbs-up"></span>&ensp;
					<b class="small">Thích</b>
				</span>
			</a>
			&ensp;&ensp;
			<a href="<?php echo($value->permalink_url); ?>" style="color: black;" target="_blank">
				<span class="glyphicon glyphicon-comment"></span>
				<b class="small">Bình luận</b>
			</a> &ensp;&ensp;
			<span class="glyphicon glyphicon-share-alt"></span>
			<b class="small" style="color:;">Chia sẻ</b>
		</div>
		<div class="rearction">
			<img src="../../emoji/like.png"  class="emoji" alt="Like">
			<img src="../../emoji/love.png"  class="emoji" alt="Love">
			<img src="../../emoji/wow.png"   class="emoji" alt="Wow">
			<img src="../../emoji/sad.png"	 class="emoji" alt="Sad">
			<img src="../../emoji/angry.png" class="emoji" alt="Angry">
			<a href="#/" title="" class="text-muted"></a>
			<a href="" target="_blank" style="float:right;" class="text-muted">
				 bình luận
			</a>
		</div>
	</div>
</div>