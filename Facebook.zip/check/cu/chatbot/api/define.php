<?php
	define('HOST', 'https://chatbot.tentstudy.xyz/');
	define('PATH_LIB', __DIR__ . '/../lib/');
	define('PATH_DB', __DIR__ . '/../db/');
	define('PATH_MEDIA', __DIR__ . '/../media/');

	// define('HOST', 'https://0e6dbadb.ap.ngrok.io/chatbot/'); // dùng để test
	