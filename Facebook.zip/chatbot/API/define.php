<?php

	define('PATH_LIB', __DIR__ . '/../lib/');
	define('PATH_DB', __DIR__ . '/../db/');
	define('PATH_MEDIA', __DIR__ . '/../media/');
	