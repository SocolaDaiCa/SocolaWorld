<?php
	$type = $_GET["type"] ?? '';
	$msg  = $_GET["msg"] ?? '';
?>

