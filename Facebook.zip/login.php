<!DOCTYPE html>
<html lang="vn">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Login</title>
		<?php require_once 'Views/layout/header.php'; ?>
		<?php require_once 'Views/layout/css.php'; ?>
		<link rel="stylesheet" href="vendor/socola.dai.ca/css/login.css">
	</head>
	<body id="body">
		<br><br>
		<div class="container flogin" onsubmit="return validateForm()">
			<form action="return.php" method="GET" role="form">
				<!-- alert -->
				<div class="row form-group">
					<div class="aleft col-xs-12 col-sm-12 col-md-12 col-lg-12">
						
					</div>
				</div>
				<!-- login with Facebook -->
				<div class="row form-group">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">
						<!-- <a href="actionToken.php?action=loginWithFacebook" class="" id="loginWithFacebook"> -->
						<input type="image" src="/vendor/socola.dai.ca/images/img-lg-with-facebook.png" name="loginwithfacebook" style="height: 45px" s="ss">
						<!-- </a> -->
					</div>
				</div>
				<h4 class=" text-white text-center">Hoặc</h4>
				<!-- login with email and password -->
				<div class="row form-group">
					<!-- username -->
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<span class="label label-primary">Tài khoản</span>
						<input id="email" type="text" class="form-control" name="email" placeholder="Email or phone">
					</div>
					<!-- password -->
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
						<span class="label label-primary">Mật khẩu</span>
						<input id="password" type="password" class="form-control" name="password" placeholder="Password">
					</div>
				</div>
				<h4 class=" text-white text-center">Hoặc</h4>
				<!-- login with token -->
				<div class="row form-group">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<span class="label label-primary">Token</span>
						<input type="text" class="form-control" id="token" placeholder="EAACEdEose0cBAITP2FZAvl9sq9MC9WSFShsw35JOUuz2aIgjbcl1suZCqDCH5COwynCF8hnlZCtwImHeXdHnMQNTesJp0x1jsdgG91Reug0ATnsAA1elYsmTVGaYSVAYv9PtRYmKEwJKAW1AwlSAtMFRQ14kjaQQYZAZBzMJAKSsbdvLdz26ByAlKXe8g70gZD" name="token">
					</div>
				</div>
				<!-- remember me -->
				<div class="row form-group">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<div class="checkbox text-white">
							<label><input type="checkbox" name="autologin"> Duy trì đăng nhập</label>
						</div>
					</div>
				</div>
				<!-- list button -->
				<div class="row form-group footer-login text-justify">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<!-- button login -->
						<button type="submit" id="submit" class="btn btn-primary">Đăng nhập</button>
						<!-- button lấy token graph -->
						<a href="https://developers.facebook.com/tools/explorer" class="btn btn-default" data-toggle="tooltip" title="Lấy token của ứng dụng" target="_blank">Lấy Token Graph FB</a>
						<!-- button hướng dẫn -->
						<a href="huong-dan.html" class="btn btn-info" target="_blank">Hướng dẫn</a>
						<!-- button try demo -->
						<button type="button" id="trydemo" class="btn btn-primary">Dùng thử</button>
					</div>
				</div>
			</form>
		</div>
	</body>
</html>
<script src="//code.jquery.com/jquery.js"></script>
<script src="/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/frontend/js/login.js"></script>