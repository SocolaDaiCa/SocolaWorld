-- MySQL dump 10.13  Distrib 5.6.39, for Linux (x86_64)
--
-- Host: localhost    Database: giosangu_socolaworld
-- ------------------------------------------------------
-- Server version	5.6.39-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apps`
--

DROP TABLE IF EXISTS `apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `controller` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `show` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `apps_category_id_foreign` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apps`
--

LOCK TABLES `apps` WRITE;
/*!40000 ALTER TABLE `apps` DISABLE KEYS */;
INSERT INTO `apps` VALUES (1,'Auto beep','','fa fa-commenting-o','auto-beep',1,'Tự động chửi, chửi không ngừng nghỉ.',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(2,'Bot Remind HashTag','','fa fa-android','bot-remind-hashtag',3,'',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(3,'Get link youtube','','fa fa fa-youtube','get-link-youtube',2,'',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(4,'Lab calendar','','fa fa-calendar','lab-calendar',1,'',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(5,'Check live Token','','fa fa-check-circle','check-live-token',1,'',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(6,'Giveway Checker','','fa fa-clone','giveway-checker',1,'',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(7,'Encode decode','','fa fa-code','encode-decode',1,'Url, Base64, md5',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(8,'Clean wall','','fa fa-eraser','clean-wall',4,'Xóa toàn bộ bài viết trên tường của bạn.',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(9,'Filter Comments','','fa fa-filter','filter-comments',1,'Lọc mail, số điện thoại, link từ bình luận.',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(10,'Ranking member','','fa fa-group','ranking-member',3,'Thống kê tương tác, xếp hạng thành viên.',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(11,'Post multiple groups','','fa fa-keyboard-o','post-multiple-groups',1,'Đăng bài trong nhiều nhóm cùng lúc.',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(12,'Filter post','','fa fa-newspaper-o','filter-post',3,'Lọc bài viết mới nhất trong nhóm.',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(13,'Get link Shutterstock','','fa fa-picture-o','get-link-shutterstock',2,'',1,'2018-03-28 13:02:58','2018-03-28 13:02:58'),(14,'Member checker','','fa fa-search','member-checker',3,'Kiểm tra thành viên thuộc nhóm A nhưng có thuộc nhóm B hay không.',1,'2018-03-28 13:02:58','2018-03-28 13:02:58');
/*!40000 ALTER TABLE `apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_remind_hash_tags`
--

DROP TABLE IF EXISTS `bot_remind_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_remind_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `messages` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashtag` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bot_remind_hash_tags_user_id_group_id_unique` (`user_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_remind_hash_tags`
--

LOCK TABLES `bot_remind_hash_tags` WRITE;
/*!40000 ALTER TABLE `bot_remind_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_remind_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorys`
--

DROP TABLE IF EXISTS `categorys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorys`
--

LOCK TABLES `categorys` WRITE;
/*!40000 ALTER TABLE `categorys` DISABLE KEYS */;
INSERT INTO `categorys` VALUES (1,'Ứng Dụng','apps','2018-03-28 13:02:57','2018-03-28 13:02:57'),(2,'get Link','get-link','2018-03-28 13:02:57','2018-03-28 13:02:57'),(3,'Quản Lý Nhóm','group','2018-03-28 13:02:57','2018-03-28 13:02:57'),(4,'Quản Lý Trang Cá Nhân','profile','2018-03-28 13:02:57','2018-03-28 13:02:57');
/*!40000 ALTER TABLE `categorys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `duty`
--

DROP TABLE IF EXISTS `duty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `duty` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `counter` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `duty_user_id_group_id_unique` (`user_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `duty`
--

LOCK TABLES `duty` WRITE;
/*!40000 ALTER TABLE `duty` DISABLE KEYS */;
/*!40000 ALTER TABLE `duty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `counter` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insight`
--

DROP TABLE IF EXISTS `insight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insight` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `posts` int(11) NOT NULL,
  `reactions` int(11) NOT NULL,
  `comments` int(11) NOT NULL,
  `member_active` int(11) NOT NULL,
  `member_count` int(11) NOT NULL,
  `member_top` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insight`
--

LOCK TABLES `insight` WRITE;
/*!40000 ALTER TABLE `insight` DISABLE KEYS */;
/*!40000 ALTER TABLE `insight` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2017_12_21_070340_create_duty_table',1),(4,'2017_12_22_050609_create_groups_table',1),(5,'2017_12_23_134822_create_insight_table',1),(6,'2017_12_24_163202_create_apps_table',1),(7,'2017_12_26_101843_create_images_table',1),(8,'2017_12_26_160438_add_column_to_table',1),(9,'2017_12_26_162507_create_vsbg_table',1),(10,'2017_12_26_192325_add_counter_to_images_table',1),(11,'2017_12_29_081604_edit_users_table',1),(12,'2017_12_29_082907_create_bot_remind_hash_tags_table',1),(13,'2018_01_09_144539_add_show_to_apps_table',1),(14,'2018_01_13_161801_create_categorys_table',1),(15,'2018_01_17_095925_create_ranking_member_table',1),(16,'2018_01_17_163935_add_user_name_to_ranking_member',1),(17,'2018_01_19_131805_edit_insight_table',1),(18,'2018_01_20_135441_edit_all_key',1),(19,'2018_01_20_163219_edit_user_table',1),(20,'2018_03_24_202829_create_table_permissions',1),(21,'2018_03_24_213636_add_foregnkey_permission_to_users_table',1),(22,'2018_03_25_130302_change_tag_to_slug_categorys_table',1),(23,'2018_03_25_131159_add_foregnkey_category_id_to_apps_table',1),(24,'2018_03_25_134844_rename_path_to_slug_apps_table',1),(25,'2018_03_25_135021_rename_descriptions_to_description_apps_table',1),(26,'2018_03_26_174146_add_controller_to_apps_table',1),(27,'2018_04_06_204109_add_avatar_to_users_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'User','2018-03-28 13:02:58','2018-03-28 13:02:58'),(2,'Admin','2018-03-28 13:02:58','2018-03-28 13:02:58');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ranking_members`
--

DROP TABLE IF EXISTS `ranking_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ranking_members` (
  `group_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `posts` int(11) NOT NULL,
  `comments` int(11) NOT NULL,
  `reactions` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`group_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ranking_members`
--

LOCK TABLES `ranking_members` WRITE;
/*!40000 ALTER TABLE `ranking_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `ranking_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_id` int(10) unsigned NOT NULL DEFAULT '1',
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_id_unique` (`user_id`),
  KEY `users_permission_id_foreign` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'1848989518674598','EAAGCwwnKIysBAMUrCoaoFS0gVVG5fhM3yy1iZCFgiQeZAEEuawuGuIKLrNRkpqUXXrlBhwUZB8B8EA2yPy06VrZAXYtkey7f7mLskfInDZCxAxZAX637kMpKVV0Sqh4nrZCj2Cph75hI8zrWPV0PdMdz3RbkGZCf6bqGUceN5sC9mIuGg3dvB8Bo','The Tien Nguyen','https://graph.facebook.com/1848989518674598/picture?type=large&redirect=true&width=40&height=40',1,'socoladaica@gmail.com','$2y$10$HWeJ1qBACJ.RGvye3BumaO1kES1Tao8rFXJV0MT11H0hZvQ.l72zy','5kMsGd6O150wz3rXwMLfwMJhjTMeyG8Mrlh2pjA3ArFpMU5gA8HUSmcjcyFN','2018-03-28 13:03:10','2018-04-06 13:43:14');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vsbg`
--

DROP TABLE IF EXISTS `vsbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vsbg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `target_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vsbg`
--

LOCK TABLES `vsbg` WRITE;
/*!40000 ALTER TABLE `vsbg` DISABLE KEYS */;
INSERT INTO `vsbg` VALUES (1,'1710126539287794',3,NULL,NULL),(2,'748231438569209',3,NULL,NULL),(3,'1958228191101926',3,NULL,NULL);
/*!40000 ALTER TABLE `vsbg` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-07  0:50:07
